export interface ReportSummaryModel {
    id: string;
    date:Date;
    formattedDate: string;
    title: string;
    year: string;
    coverPhoto: string;
  }
  